import React from "react";
import ProfileCss from "./Profile.module.css";
import profileuser from "./image/profileuser.jpg";

const Profile = ({ userInfo }) => {
  // const { userEmail, userName, profileImageUrl, authority } = userInfo;
  // userInfo가 null 또는 undefined인 경우 빈 객체로 초기화
  const {
    userEmail = "",
    userName = "",
    profileImageUrl = "",
    authority = "크리에이터"
  } = userInfo || {};

  return (
    <div className={ProfileCss.Container}>
      <div className={ProfileCss.Wrap}>
        <div className={ProfileCss.Img}>
          <img src={profileuser} />
        </div>
        <div
          className={`${ProfileCss.Item} ${
            authority === "광고주"
              ? ProfileCss.Advertiser
              : authority === "크리에이터"
              ? ProfileCss.Creator
              : authority === "관리자"
              ? ProfileCss.Admin
              : ""
          }`}
        >
          <div className={ProfileCss.Items}>
            <div className={ProfileCss.Name}>{userName}</div>
            <div className={ProfileCss.Authority}>{authority}</div>
          </div>
          <div className={ProfileCss.Email}>{userEmail}</div>
        </div>
        <div className={ProfileCss.Btn}>
          <button>수정</button>
        </div>
      </div>
    </div>
  );
};
export default Profile;
