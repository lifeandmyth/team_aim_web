import React, { useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import "./MyPageMatchingRejModal.css";

const MyPageMatchingRejModal = () => {
  const { matchingIdx } = useParams();
  const [userEmail, setUserEmail] = useState('');
  const [reasons, setReasons] = useState("");
  const [otherReason, setOtherReason] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(true);

  const navigate = useNavigate();

  /* 체크 항목 */
  const handleRadioChange = (e) => {
    setReasons(e.target.value);
    if (e.target.value !== "other") {
      setOtherReason("");
    }
  };

  // 기타 항목 작성
  const handleOtherReasonChange = (e) => {
    setOtherReason(e.target.value);
  };

  /* 확인 메세지 */
  const handleSubmit = async () => {
    if (!reasons) {
      alert("항목을 선택해주세요.");
    } else if (reasons === "other" && !otherReason) {
      alert("기타 사유를 입력하세요.");
    }  else {
      const isConfirmed = window.confirm("정말로 매칭을 거절하시겠습니까?");
      if (isConfirmed) {
        try {
          const response = await axios.put(
             `http://localhost:8080/api/user/matching/mypage/user25@email.com/${matchingIdx}/status?status=2`
            //`http://localhost:8080/api/user/matching/mypage/${userEmail}${matchingIdx}/status?status=2`
          );
          console.log("매칭 거절 응답 성공:", response);
          alert("거절 사유가 제출되었습니다.");
          setIsModalOpen(false);
          navigate(`/mypage/main`);
        } catch (error) {
          console.error("매칭 거절 오류:", error);
        }
      }
    }
  };

  /* 모달 닫기*/
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  if (!isModalOpen) {
    return null;
  }

  return (
    <div className="MyPage-Reject-Modal-Container">
      <h2>매칭 거절 사유</h2>
      <div className="MyPage-Reject-Modal-Wrap">
        <label>
          <input
            type="radio"
            name="reason"
            value="condition"
            checked={reasons === "condition"}
            onChange={handleRadioChange}
          />
          제시된 조건이 만족스럽지 않음
        </label>
        <label>
          <input
            type="radio"
            name="reason"
            value="conceptMismatch"
            checked={reasons === "conceptMismatch"}
            onChange={handleRadioChange}
          />
          광고 컨셉이 채널과 맞지 않음
        </label>
        <label>
          <input
            type="radio"
            name="reason"
            value="lackOfAdvertiserInfo"
            checked={reasons === "lackOfAdvertiserInfo"}
            onChange={handleRadioChange}
          />
          회사에 대한 정보가 부족함
        </label>
        <label>
          <input
            type="radio"
            name="reason"
            value="duplicateConcept"
            checked={reasons === "duplicateConcept"}
            onChange={handleRadioChange}
          />
          광고 주제나 콘셉트가 유사한 다른 협찬과 중복됨
        </label>
        <label>
          <input
            type="radio"
            name="reason"
            value="other"
            checked={reasons === "other"}
            onChange={handleRadioChange}
          />
          기타
          {reasons === "other" && (
            <textarea className="MyPage-Reject-Modal-Text"
              placeholder="기타 사유를 입력하세요"
              value={otherReason}
              onChange={handleOtherReasonChange}
            />
          )}
        </label>
        <div className="MyPage-Reject-Modal-btn">
          <button onClick={handleSubmit}>확인</button>
          <button onClick={handleCancel}>취소</button>
        </div>
      </div>
    </div>
  );
};

export default MyPageMatchingRejModal;
