import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Profile from "./Profile";
import MypageCss from "./Mypage.module.css";
import MatListCss from "./MatchingList.module.css";
import profileuser from "./image/profileuser.jpg";

const ITEMS_PER_PAGE = 5;

const Mypage = () => {
  const [userInfo, setUserInfo] = useState(null);
  const [matchingList, setMatchingList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedItem, setSelectedItem] = useState(null);
  const [formData, setFormData] = useState([]);
  const navigate = useNavigate();

  const profileImgUrl = profileuser;

  useEffect(() => {
    // 토큰을 가져오는 함수 또는 방법에 따라 수정해야 합니다.
    const token = localStorage.getItem("token"); // 로컬 스토리지에서 토큰을 가져옴

    // 유저 정보를 받아오는 API 요청
    const fetchUserInfo = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/user/info/user25@email.com`,
          //   `http://localhost:8080/api/user/info/${userEmail}`,
          {
            headers: {
              Authorization: `Bearer ${token}` // 토큰을 Authorization 헤더에 담아 전송
            }
          }
        );
        console.log("데이터 불러오기 성공:", response.data);
        setUserInfo(response.data);
      } catch (error) {
        console.error("데이터 불러오기 오류:", error);
      }
    };
    // 매칭 정보를 받아오는 API 요청
    const fetchMatchingList = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/user/matching/mypage/user25@email.com`,
          //   `http://localhost:8080/api/user/matching/mypage/${userEmail}`,
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        );
        console.log("매칭 정보 불러오기 성공:", response.data);
        // 매칭 리스트를 내림차순으로 정렬
        const data = response.data;
        const dataArray = Object.values(data);
        const sortedDataArray = dataArray.sort(
          (a, b) => b.matchingIdx - a.matchingIdx
        );
        setFormData([...sortedDataArray]);
        setMatchingList(response.data);
      } catch (error) {
        console.error("매칭 정보 불러오기 오류:", error);
      }
    };
    // 토큰이 유효한 경우에만 API 요청 수행
    // if (token) {
    fetchUserInfo();
    fetchMatchingList();
    // }
  }, []);


  const handleItemClick = (matchingIdx) => {
    const formDataItem = matchingList.find(
      (item) => item.matchingIdx === matchingIdx
    );
    if (formDataItem) {
      console.log("페이징 이동 해야 함", formDataItem);
      setSelectedItem(formDataItem);
      navigate(`/matching/detail/${formDataItem.matchingIdx}`);
    }
  };

   // 현재 페이지에 해당하는 아이템을 계산
   const indexOfLastItem = currentPage * ITEMS_PER_PAGE;
   const indexOfFirstItem = indexOfLastItem - ITEMS_PER_PAGE;
   const currentItems = matchingList.slice(indexOfFirstItem, indexOfLastItem);

    // 페이지네이션을 위한 페이지 번호 목록 계산
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(matchingList.length / ITEMS_PER_PAGE); i++) {
      pageNumbers.push(i);
    }

  // 이전 페이지로 이동하는 함수
  const goToPreviousPage = () => {
    setCurrentPage((prev) => prev - 1);
  };

  // 다음 페이지로 이동하는 함수
  const goToNextPage = () => {
    setCurrentPage((prev) => prev + 1);
  };

  return (
    <div className={MypageCss.Container}>
      <div className={MypageCss.Wrap}>
        <h2 className={MypageCss.Font}>프로필</h2>
        <Profile userInfo={userInfo} />
        <h2 className={MypageCss.Font}>매칭 리스트</h2>
        <div className={MatListCss.Container}>
          <div className={MatListCss.Wrap}>
            <div
              className={MatListCss.WrapHeader}
              style={{ display: "flex", width: "100%" }}
            >
              <div className={MatListCss.HeaderIndex} style={{ width: "10%" }}>
                번호
              </div>
              <div className={MatListCss.HeaderDate} style={{ width: "20%" }}>
                날짜
              </div>
              <div
                className={MatListCss.HeaderProvider}
                style={{ width: "20%" }}
              >
                회사명
              </div>
              <div className={MatListCss.HeaderStatus} style={{ width: "10%" }}>
                상태
              </div>
              <div className={MatListCss.HeaderTitle} style={{ width: "40%" }}>
                제목
              </div>
            </div>
            <div className={MatListCss.WrapRow}>
              {currentItems.map((matchingItem, index) => (
                <div
                  key={matchingItem.matchingIdx}
                  className={`${MatListCss.Status} ${
                    matchingItem.status === 2
                      ? MatListCss.Rejected
                      : matchingItem.status === 1
                      ? MatListCss.Accepted
                      : MatListCss.Pending
                  }`}
                  onClick={() => handleItemClick(matchingItem.matchingIdx)}
                >
                  <div
                    className={MatListCss.WrapRow}
                    style={{ display: "flex", width: "100%" }}
                  >
                    <div className={MatListCss.Index} style={{ width: "10%" }}>
                      {(currentPage - 1) * ITEMS_PER_PAGE + index + 1}
                    </div>
                    <div className={MatListCss.Date} style={{ width: "20%" }}>
                      {matchingItem.date}
                    </div>
                    <div
                      className={MatListCss.Provider}
                      style={{ width: "20%" }}
                    >
                      {matchingItem.provider}
                    </div>
                    <div className={MatListCss.Status} style={{  
                      width: "10%",
                      color: matchingItem.status === 0 ? "black" : matchingItem.status === 1 ? "#59b597" : "#f2380a"
                    }}>
                      {matchingItem.status === 0
                        ? "대기"
                        : matchingItem.status === 1
                        ? "승인"
                        : "거절"}
                    </div>
                    <div className={MatListCss.Title} style={{ width: "40%" }}>
                      {matchingItem.matchingTitle}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {/* 페이징 */}
            <div className={MatListCss.Btn}>
              <button
                className={MatListCss.BtnSide}
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
              >
                이전
              </button>
              {/* 페이지네이션 */}
              <div className={MatListCss.PaginBtnNumation}>
                {pageNumbers.map((number) => (
                  <button
                    key={number}
                    className={`${MatListCss.BtnNum} ${
                      currentPage === number ? MatListCss.active : ""
                    }`}
                    onClick={() => setCurrentPage(number)}
                  >
                    {number}
                  </button>
                ))}
              </div>
              <button
                className={MatListCss.BtnSide}
                onClick={goToNextPage}
                disabled={indexOfLastItem >= formData.length}
              >
                다음
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Mypage;
