import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import MyPageMatchingRejModal from "./MyPageMatchingRejModal";
import MPDetailCss from "./MatchingDetail.module.css";

const MatchingDetail = () => {
  const { matchingIdx } = useParams();
  const [matchingList, setMatchingList] = useState([]);
  const [matchingData, setMatchingData] = useState({});
  const [userEmail, setUserEmail] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // 토큰을 가져오는 함수 또는 방법에 따라 수정해야 합니다.
    const token = localStorage.getItem("token"); // 로컬 스토리지에서 토큰을 가져옴

    // 매칭 정보를 받아오는 API 요청
    const fetchMatchingList = async () => {
      try {
        const response = await axios.get(
            `http://localhost:8080/api/user/matching/mypage/user25@email.com/${matchingIdx}`,
          //`http://localhost:8080/api/user/matching/mypage/${userEmail}/${matchingIdx}`,
          // {
          //   headers: {
          //     Authorization: `Bearer ${token}`
          //   }
          // }
        );
        console.log("매칭 정보 불러오기 성공>>>>:", response.data);
        setMatchingList(response.data);
      } catch (error) {
        console.error("매칭 정보 불러오기 오류:", error);
      }
    };
    // 토큰이 유효한 경우에만 API 요청 수행
    // if (token) {
    fetchMatchingList();
    // }
  }, []);


  /* 매칭 수락 후 마이페이지 매칭리스트 페이지 */
  const handleAccept = async () => {
    const isConfirmed = window.confirm("정말로 수락하시겠습니까?");
    try {
      const response = await axios.put(
        `http://localhost:8080/api/user/matching/mypage/user25@email.com/${matchingIdx}/status?status=1`
        // `http://localhost:8080/api/user/matching/mypage/${userEmail}${matchingIdx}/status?status=1`
      );
      
      console.log("매칭 수락 성공:", response.data);
      navigate("/mypage/main");
      // 수락 성공 후 필요한 로직 추가
    } catch (error) {
      console.error("매칭 수락 오류:", error);
    }
  };


  /* 매칭 거절 후 사유 모달 */
  const openMatchingRejectModal = () => {
    setIsModalOpen(true);
    console.log("Rejected");
  };

  /* 거절 모달 창이 닫힐 때 호출될 함수 */
  const closeMatchingRejectModal = () => {
    setIsModalOpen(false);
  };

  if (!matchingData) {
    return null;
  }

  return (
    <div className={MPDetailCss.Root}>
      <div className={MPDetailCss.Container}>
        <h2 className={MPDetailCss.Font}>광고 요청 확인</h2>

        <div className={MPDetailCss.Wrap}>
          <div className={MPDetailCss.Top}>
            <div className={MPDetailCss.Status}></div>
            <div className={MPDetailCss.Title}>
              {matchingList.matchingTitle}
            </div>
            <div className={MPDetailCss.TopRight}>
              <div className={MPDetailCss.Date}>{matchingList.date}</div>
            </div>
          </div>

          <div className={MPDetailCss.FormItem}>
            <div className={MPDetailCss.FormItem1}>
              <div className={MPDetailCss.Item}>회사명</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.provider}
              </div>
            </div>
            <div className={MPDetailCss.FormItem2}>
              <div className={MPDetailCss.Item}>담당자</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.userSendName}
              </div>
            </div>
            <div className={MPDetailCss.FormItem3}>
              <div className={MPDetailCss.Item}>광고 소개</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.matchingDetails}
              </div>
            </div>
            <div className={MPDetailCss.FormItem4}>
              <div className={MPDetailCss.Item}>의뢰 목적</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.matchingGoal}
              </div>
            </div>
            <div className={MPDetailCss.FormItem5}>
              <div className={MPDetailCss.Item}>광고 예산</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.matchingCostsMin}원 ~ {matchingList.matchingCostsMax}원
              </div>
            </div>
            <div className={MPDetailCss.FormItem6}>
              <div className={MPDetailCss.Item}>제작 방식</div>
              <div className={MPDetailCss.SelectedItem}>
                {matchingList.adMethodsDetails}
              </div>
            </div>
          </div>
          <div className={MPDetailCss.Btn}>
            <button className={MPDetailCss.BtnAccept} onClick={handleAccept}>
              수락
            </button>
            <button
              className={MPDetailCss.BtnReject}
              onClick={openMatchingRejectModal}
            >
              거절
            </button>
            {isModalOpen && (
              <MyPageMatchingRejModal closeModal={closeMatchingRejectModal} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default MatchingDetail;
