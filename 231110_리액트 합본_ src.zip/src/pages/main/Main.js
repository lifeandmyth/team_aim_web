import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { callMainListAPI } from "../../apis/MainAPICall";
import {
  callSearchKeywordsAPI,
  callKeywordHistoryAPI
} from "../../apis/SearchAPICall";
import MainCss from "../main/Main.module.css";
import RankingKeyword from "../../component/Rankingkeyword";
import BannerSlider from "../../component/BannerSlider";

function Main() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const crawl = useSelector((state) => state.mainReducer);
  const mainList = crawl.data;

  const [keywords, setKeywords] = useState("");

  const currentTime = new Date().toISOString();
  const requestData = {
    keywords: keywords, // 검색할 키워드
    searchDate: currentTime // 현재 시간을 검색 시간으로 사용
  };

  function formatCount(count) {
    let value;

    if (count >= 10000) {
      value = (count / 10000).toFixed(2);
    } else if (count >= 1000) {
      value = (count / 1000).toFixed(2);
    } else {
      return count;
    }

    // 소수점 뒤에 불필요한 0을 제거
    value = parseFloat(value).toString();

    if (count >= 10000) {
      return value + "만";
    } else {
      return value + "천";
    }
  }

  // const pageInfo = crawl.pageInfo;
  const [currentPage, setCurrentPage] = useState(1);
  const pagesize = 10;
  // const pageNumber = [];
  // if(pageInfo){
  //     for(let i = 1; i <= pageInfo.pageEnd ; i++){
  //         pageNumber.push(i);
  //     }
  // }

  /* 검색 키업 핸들러 */
  const onEnterKeyHandler = (e) => {
    if (e.key === "Enter") {
      console.log("Enter key", keywords);

      navigate(`/search?keywords=${keywords}`, { replace: true });
      dispatch(
        callSearchKeywordsAPI({
          currentPage: currentPage,
          keywords: keywords
        })
      );

      dispatch(callKeywordHistoryAPI(requestData));

      window.location.reload();
    }
  };

  /* 검색 체인지 핸들러 */
  const onSearchChangeHandler = (e) => {
    setKeywords(e.target.value);
  };

  const handleKeywordClick = (keyword) => {
    // 현재 페이지 정보나 다른 필요한 정보와 함께 API를 호출합니다.
    dispatch(
      callSearchKeywordsAPI({
        currentPage: currentPage,
        keywords: keyword
      })
    );
    navigate(`/search?keywords=${keyword}`);
  };

  useEffect(() => {
    dispatch(
      callMainListAPI({
        currentPage: currentPage
      })
    );
  }, [dispatch, currentPage]);

  // 버튼에 적용할 스타일 객체
  const buttonStyle = {
    border: "none",
    color: "white"
  };

  // 1순위 버튼 스타일
  const oneButtonStyle = {
    ...buttonStyle,
    backgroundColor: "#6750a4"
  };

  // 그 외 버튼 색깔
  const etcButtonStyle = {
    ...buttonStyle,
    backgroundColor: "#D0BCFF"
  };

  return (
    <>
      {/* <div className={MainCss.container}>
        <div className={MainCss.image}>
          <span className={MainCss.text}></span>
          <input
                        className={ MainCss.input }
                        type='text'
                        placeholder='검색어를 입력하세요'
                        value={ keywords }
                        onKeyUp={ onEnterKeyHandler }
                        onChange={ onSearchChangeHandler }
                    />
        </div>
      </div> */}

      <BannerSlider/> 

      <RankingKeyword />

      {/* <div className="Main-List-Container">
        <div className="Main-List-Title">
          <b className="Main-ListTitle1">채널명</b>
          <b className="Main-ListTitle2">구독자</b>
          <b className="Main-ListTitle3">대표 키워드</b>
        </div>
        <div className="Main-List-Wrap">
          <div className="Main-ListItem">
            {Array.isArray(mainList) &&
              mainList.slice(0, pagesize).map((p) => (
                <ul key={p.channel_idx}>
                  <li className="Main-UserImage">
                    <img src={p.channel_image} className="Main-UserImage" />
                  </li>
                  <li className={MainCss.channelName}>{p.channel}</li>
                  <li className={MainCss.subscriberCount}>
                    {formatCount(p.subscriber_count)}명
                  </li>
                  <li className={MainCss.keywords}>
                    {p.keyword.split(",").map((keyword, index) => (
                      <button
                        key={index}
                        className={MainCss.keywordBtn}
                        onClick={() => handleKeywordClick(keyword.trim())}
                        style={{
                          ...(index === 0 ? oneButtonStyle : etcButtonStyle),
                          marginRight: "10px"
                        }}
                      >
                        {keyword}
                      </button>
                    ))}
                  </li>
                </ul>
              ))}
          </div>
        </div>
      </div> */}

      {/* 잠시 주석 */}
      <div className={MainCss.mainListContainer}>
        <div className={MainCss.mainList}>
          <div className={MainCss.mainTitle}>
            <b className={MainCss.ListTitle1}>채널명</b>
            <b className={MainCss.ListTitle2}>구독자</b>
            <b className={MainCss.ListTitle3}>대표키워드</b>
          </div>
          <div className={MainCss.mainListWrap}>
            {Array.isArray(mainList) &&
              mainList.slice(0, pagesize).map((p) => (
                <ul key={p.channel_idx}>
                  <li className={MainCss.userimageForm}>
                    <img
                      src={p.channel_image}
                      className={MainCss.userimage}
                      style={{ width: "60px", height: "60px" }}
                    />
                  </li>
                  <li className={MainCss.channelName}>{p.channel}</li>
                  <li className={MainCss.subscriberCount}>
                    {formatCount(p.subscriber_count)}명
                  </li>

                  <li className={MainCss.keywords}>
                    {p.keyword.split(",").map((keyword, index) => (
                      <button
                        key={index}
                        className={MainCss.keywordBtn}
                        onClick={() => handleKeywordClick(keyword.trim())}
                        style={{
                          ...(index === 0 ? oneButtonStyle : etcButtonStyle),
                          marginRight: "10px"
                        }}
                      >
                        {keyword}
                      </button>
                    ))}
                  </li>
                </ul>
              ))}
          </div>
        </div>
      </div>

      {/* <div className={MainCss.pageBtndiv}>
                { Array.isArray(mainList) &&
                    <button 
                        onClick={() => setCurrentPage(currentPage - 1)} 
                        disabled={currentPage === 1}
                    >
                        &lt;
                    </button>
                }
                {pageNumber.map((num) => (
                    <div key={num} onClick={() => setCurrentPage(num)}>
                        <button
                            style={ currentPage === num ? {backgroundColor : 'yellowgreen' } : null}
                        >
                            {num}
                        </button>
                    </div>
                ))}
                { Array.isArray(mainList) &&
                    <button 
                        onClick={() => setCurrentPage(currentPage + 1)} 
                        disabled={currentPage === pageInfo.pageEnd  || pageInfo.total === 0}
                    >
                        &gt;
                    </button>
                }
            </div> */}
    </>
  );
}

export default Main;
