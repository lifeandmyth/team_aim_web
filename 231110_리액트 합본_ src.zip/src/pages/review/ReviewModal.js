import React, { useEffect, useState } from 'react';
import Reviewcss from './ReviewModal.module.css';
import axios from 'axios';

function Modal({ isOpen, closeModal }) {


    const [reviewData, setReviewData] = useState({
        channelIdx: 100,
        managerId: 1,
        title: '강아지를 위해 120평 마당에 잔디를 깔아줫더니...',
        views: 204230,
        uploadDate: '2023-11-06 00:00:00',
        cmtVibeGood: 230,
        cmtVibeBad: 56,
        thumbUrl: 'https://img.youtube.com/vi/PsSPHAJjzfg/0.jpg',
        vidUrl: 'url',
    });
    // private int channelIdx;
    // private int managerId;
    // private String title;
    // private int views;
    // private String uploadDate;
    // private int cmtVibeGood;
    // private int cmtVibeBad;
    // private String thumbUrl;
    // private String vidUrl;

      // 모달창이 켜져있으면 뒤에 스크롤 안움직이게 하기
    console.log(reviewData)
    useEffect(() => {
        if (isOpen) {
        document.body.style.overflow = 'hidden';
        } else {
        document.body.style.overflow = 'visible';
        }
    
        return () => {
        document.body.style.overflow = 'visible';
        };
    }, [isOpen]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setReviewData({
        ...reviewData,
        [name]: value
        });
    };
     
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          await axios.post('http://localhost:8080/review/modal', reviewData, 
          {headers: {
            'Content-Type': 'application/json'
          }});
          alert('Review submitted successfully');
          // 페이지 새로고침
          window.location.reload();
        } catch (error) {
          console.error('Failed to submit review:', error);
          alert('Error submitting review');
        }
    };
    

    return (
        <div className= {Reviewcss.ReviewWrap}>
        <div className={Reviewcss.RcontentWrap}>
            <span
                onClick={closeModal}
                className= {Reviewcss.Rmodal_close}
            >
                X
            </span>
            <div className= {Reviewcss.RcontentTitle}>
                <h2>리뷰등록</h2>
            </div>

        
            <div className= {Reviewcss.Rcontent}>
                <div className={Reviewcss.RinputTitle}>
                    영상 URL
                </div>
            <div className={Reviewcss.RinputWrap}>
                <input 
                type='text' 
                name="vidUrl"
                className='Rinput'
                value={reviewData.vidUrl}
                placeholder='영상링크를 넣어주세요.'
                onChange={handleInputChange}
                />
            </div>
            </div>

            <div className= {Reviewcss.Rcontent}>
                <div  className={Reviewcss.RinputTitle}>
                    설명
                </div>
            <div className={Reviewcss.RinputWrap}>
                <input 
                type='text' 
                className='Rinput'
                placeholder='설명을 넣어주세요.'
                // onChange={handleTitleChange}
                />
            </div>
            </div>

            <div className={Reviewcss.RbuttonWrap}>
                <button type="submit" onClick={handleSubmit} className={Reviewcss.Rbutton} >등록하기</button>
            </div>
            
        </div>
        </div>
    );
  }
  
  export default Modal;