// Review.js
import css from './Review.module.css';
import { callReviewListAPI } from '../../apis/ReviewAPICall';
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from 'react-redux';
import dayjs from 'dayjs';
// 모달창 호출
import Modal from "./ReviewModal";




function Review() {

  const dispatch = useDispatch();
  
  const crawl = useSelector(state => state.reviewReducer);
  // const [reviewList] = useState([]);
  const reviewList = crawl.data;
  const [currentPage] = useState('');
  // const [count] = useState(reviewList);

  console.log(reviewList)

  // console.log([count])

  // for(let i=0; i < reviewList.length; i++) {
  //   count++;
  // }
  // console.log(count)

  

  useEffect(
    () => {
        dispatch(callReviewListAPI({
            currentPage: currentPage
        }));            
    }
    // useEffect가 dispatch로 호출한 API로 re-rendering하는 과정
    // 그 자체이기 때문에 dispatch를 또 담아 제출할 필요 없음
    ,[currentPage]
  );
    // 모달창 열기
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  
  return (
    <div className={css.riview_wrap}>
    <div className={css.review_container}>
      <section className={css.uploads_section}>
        <div className={css.upload_item} >
          {/* javascript의 length 속성을 사용하려면 함수의 return 안에서 쓰거나
          함수 밖에서 적용해야 함 */}
          <p>지금까지 총 {reviewList?.length}건의 매칭이 성사되었습니다.</p>
        </div>
      </section>
      
      {/* <section className={css.public_section}>
        <div className={css.public_item}>
          <img src={ item_image } alt="Minimal photography" />
        {/* </div>
      </section> */}
      <div className={css.regbuttonWrap}>
        <button className={css.regbutton} onClick={openModal}>등록</button>
        {/* <Modal isOpen={isModalOpen} content="Hi. It's me, Mario!" closeModal={closeModal} /> */}
        {isModalOpen && <Modal isOpen={isModalOpen}  closeModal={closeModal} />}
      </div>
      
      <div style={{ listStyleType: "none", display: "flex", justifyContent: "center" }}>
                <section>
                    {/* <colgroup>
                        <col width="20%"/>
                        <col width="20%"/>
                        <col width="20%"/>
                    </colgroup> */}
                    <div className={css.upload_yt_section}>

                          
                          {/* <span>제목</span>
                              <p>조회수</p>
                              <p>업로드 날짜</p>
                              <p>긍정 댓글 수</p>
                              <p>부정 댓글 수</p>
                              <p>썸네일</p>
                              <p>영상 URL</p> */}
                            { Array.isArray(reviewList) && reviewList.map((r) => (

                                <section key={ r.review_idx } className={css.upload_yt_box}>
                                    <a href={ r.vid_url } target='_blank'>
                                      <img src={ r.thumb_url } alt='no_img'></img>
                                      <div className={css.title}>{ r.title }</div>
                                      {/* 단순 연산은 Number() 안에 담아 덧셈~곱셈 가능 */}
                                      {/* 이후 소숫점 처리 필요 */}
                                      <div className={css.cmt_vibe}>시청자 만족도: {Math.round(Number(r.cmt_vibe_good)/(Number(r.cmt_vibe_good) + Number(r.cmt_vibe_bad))*100)} (%)</div>
                                      <section>
                                        <div className={css.views}>조회수: { r.views }</div>
                                        <div className={css.upload_date}>등록 날짜: {dayjs(r.upload_date).format('YYYY. MM. DD')}</div>
                                      </section>
                                      
                                    </a>

                                </section>
                            )) 
                          }
                          

                    </div>
                </section>
            </div>

    

    </div>
    </div>
  );
  
}

export default Review;


