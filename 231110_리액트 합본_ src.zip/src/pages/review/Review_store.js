import { createStore } from 'redux'

const reducer = (state, action) => {
if (state === undefined) {
    return {
    name: 'userA',
    };
}
if (action.type === 'CHANGE') {
    return {
    ...state,
    name: action.name,
    };
}
};

const review_store = createStore(reducer);

export default review_store;