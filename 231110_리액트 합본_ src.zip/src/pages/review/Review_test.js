// import React, { useState, useReducer  } from "react";



// // useState 예제:

// import React, { useState, useReducer  } from "react";
// const Tab = [
//   {
//     title: "section1",
//     content: "im content 1"
//   },
//   {
//     title: "section2",
//     content: "im content 2"
//   },
//   {
//     title: "section3",
//     content: "im content 3"
//   }
// ];
// // in: 초기 탭 idx, 탭 리스트 out: 탭 리스트 아이템 , set인덱스
// const useTab = (idx, Tabs) => {
//   const [CurrentIdx, SetCurrentIdx] = useState(idx);

//   if (!Tabs || !Array.isArray(Tabs)) {
//     return null;
//   }
//   return {
//     CurrentItem: Tabs[CurrentIdx],
//     ChangeItem: SetCurrentIdx
//   };
// };


// export default function AppReview() {
//   const { CurrentItem, ChangeItem } = useTab(0, Tab);
//   return (
//     <div className="AppReview">
//       <h1>InputHooks with validator</h1>
//       <div>
//         {Tab.map((e, index) => (
//           <button key={index} onClick={e => ChangeItem(index)}>
//             {e.title}
//           </button>
//         ))}
//       </div>
//       <div>{CurrentItem.content}</div>
//     </div>
//   );
// };

// export default function AppReview2() {
  
//   // const text = ''
//   const initialState = {count: 0, text: ''};
  

//   function reducer(state, action) {
//     switch (action.type) {
//       case 'increment':
//         return {count: state.count + 1, text: '+'};
//       case 'decrement':
//         return {count: state.count - 1, text: '-'};
//       default:
//         throw new Error();
//     }
//   }
  
  
//   const [state, dispatch] = useReducer(reducer, initialState);
//   return (
//     <>
//       Count: {state.count}
//       <button onClick={() => dispatch({type: 'decrement'})}>-</button>
//       <button onClick={() => dispatch({type: 'increment'})}>+</button>
//       {/* 왜 자꾸 text가 정의되있지 않다고 error가 뜨는건지 모르겠음 */}
//       <div>{initialState.text}를 눌렀습니다.</div>
//     </>
//   );  
// }


// // useEffect 사용법
// import { useState, useEffect } from "react";

// export default function AppReview() {
//   const [count, setCounter] = useState(0);

//   useEffect(() => {
//     console.log(`useEffect: ${Date()}`);
//   });

//   const countHandler = (e) => {
//     setCounter((s) => s + 1);
//   };

//   return (
//     <div className="App">
//       <h1 id="hi">{count}</h1>
//       <button onClick={countHandler}>카운터 증가</button>
//     </div>
//   );
// }

