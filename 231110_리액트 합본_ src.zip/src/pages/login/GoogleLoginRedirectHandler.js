import React, { useEffect } from 'react';

const GoogleLoginRedirectHandler = () => {
  useEffect(() => {
    // URL에서 'code' 파라미터 가져오기
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');

    // 여기에 window.opener의 값 로깅
    console.log('window.opener:', window.opener);

    if (code) {
      // 메인 윈도우에 인증 코드 전송
      if (window.opener && typeof window.opener.postMessage === 'function') {
        // postMessage 호출 전에 window.opener의 값과 postMessage 함수 로깅
        console.log('Before postMessage:', window.opener, window.opener.postMessage);
        
        window.opener.postMessage({ code: code }, window.location.origin);
        console.log(code, '가 있다면 팝업창 닫기');
        
        // postMessage 호출 후에 window.opener의 값 로깅
        console.log('After postMessage:', window.opener, window.opener.postMessage);

        // 팝업 창 닫기
          window.close();
      } else {
        console.error('메인 윈도우에 메시지를 전송할 수 없습니다.');
      }
    } else {
      // 에러 처리: 'code' 파라미터가 없을 경우
      console.error('Google OAuth2.0 인증 코드가 URL에 없습니다.');
    }
  }, []);

  return (
    <div>
      Google 로그인 리디렉션 처리중...
    </div>
  );
};

export default GoogleLoginRedirectHandler;
