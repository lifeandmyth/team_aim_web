import React from 'react';
import youtubeicon from '../../image/youtubeicon.png'
import axios from 'axios';


const YoutubeLoginButton  = (res) => {
  const clientId = '362805316263-0silf7gkhrvpoqk5l7v9t4gdl3b88vg2.apps.googleusercontent.com'

  const openyoutubeWindow = async () => {
    const width = 600;
    const height = 600;
    const left = window.innerWidth / 2 - width / 2;
    const top = window.innerHeight / 2 - height / 2;

    const options = `width=${width},height=${height},left=${left},top=${top}`;
    
    const youtubeLoginWindow = window.open(
      `https://accounts.google.com/o/oauth2/v2/auth?scope=profile%20email&response_type=code&client_id=${clientId}&redirect_uri=http://localhost:3000/googlelogin`,
      '_blank',
      options
    );

    if (youtubeLoginWindow) {
      youtubeLoginWindow.focus();
      // OAuth 2.0 인증 코드를 받아오기 위한 작업
      const oauth2Response = await new Promise((resolve) => {
        window.addEventListener('message', (event) => {
          if (event.origin === window.location.origin) {
            resolve(event.data);
            console.log('처음들어오는코드', event.data)
          }
        });
      });

      // 서버로 OAuth 2.0 인증 코드를 전송
      try{
      console.log('코드받아오기',  oauth2Response.code)

      const response = await axios.post(`http://localhost:3000/googlelogin`, {
        code: oauth2Response.code, // 인증 코드 
      });

       // JWT 토큰을 받는다
        const jwtToken = response.data;

        console.log('JWT 토큰:', jwtToken);

      // 로컬 스토리지에 JWT 토큰 저장 (옵션)
        localStorage.setItem('token', jwtToken);

      // 로그인 후의 작업을 수행 (예: 메인 페이지로 리디렉션)
      if (response.status === 200) {
        window.location.href = '/'; // 메인 페이지 URL로 리디렉션
        console.log("로그인 성공!!!!")
      }
    }catch (error) {
      console.log('여기는 에러,코드도확인', oauth2Response.code)
      console.error("Google 로그인 오류!!!!:", error);
    }
   }
  };

  return (
    <div className='ylogin'>
      <img src={youtubeicon} alt="YouTube Icon" />
      <button onClick={openyoutubeWindow}>
      <h3>YouTube 계정으로 로그인</h3>
      </button>
    </div>
  );
};


export default YoutubeLoginButton;
