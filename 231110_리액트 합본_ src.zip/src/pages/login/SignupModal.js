import React, { useState, useEffect } from "react";
//import axios from "axios";
import "./SignupModal.css";
import axios from "axios";

const SignupModal = ({ isOpen, onClose }) => {
  // 모달이 열려있을 때에만 Hooks를 호출
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");

  

  const handleSignup = () => {
    console.log("여기가 처음시작");
    // 유효성 검사 로직 추가
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[\d@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    const phoneRegex = /^01[0-6]-\d{3,4}-\d{4}$/;

    if (!email || !password || !confirmPassword || !phone) {
      setError("모든 필드를 입력해주세요.");
      return;
    }

    if (!emailRegex.test(email)) {
      setError("올바른 이메일 주소를 입력해주세요.");
      console.log("여기가 이메일주소입력칸");
      return;
    }

    if (!passwordRegex.test(password)) {
      setError(
        "비밀번호는 최소 8자 이상, 특수문자 또는 숫자를 포함해야 합니다."
      );
      return;
    }

    if (password !== confirmPassword) {
      setError("비밀번호가 일치하지 않습니다.");
      return;
    }

    if (!phoneRegex.test(phone)) {
      setError("올바른 연락처를 입력해주세요.");
      return;
    }

    console.log("서버요청전 들어가겠지?");

       /* 회원가입 서버 요청 */
       axios
       .post("http://localhost:8080/api/user/signup", {
         userEmail: email,
         userPassword: password,
         userPhone: phone
       })
       .then((response) => {
          console.log("응답받아야함!!!");
         if (response.data === "아이디 중복") {
           setError("등록된 아이디가 이미 존재합니다.");
         } else {
           console.log("회원가입 성공:", response.data);
           setError("");
           onClose();
           window.alert("회원가입이 성공적으로 완료되었습니다!");
         }
       })
       .catch((error) => {
        console.log("여기가 응답실패야???!!!!!!!!");
         console.error("회원가입 실패:", error);
         setError("회원가입에 실패했습니다. 다시 시도해주세요.");
       });
   };


   const isFormValid = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[\d@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    const phoneRegex = /^01[0-6]-\d{3,4}-\d{4}$/;

    return (
      emailRegex.test(email) &&
      passwordRegex.test(password) &&
      password === confirmPassword &&
      phoneRegex.test(phone)
    );
  };
  


  //  모달이 열릴 때마다 상태 초기화
  useEffect(() => {
    if (isOpen) {
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setPhone("");
      setError("");
    }
  }, [isOpen]);




  // 모달이 닫혀있을 때에는 아무것도 렌더링하지 않습니다.
  if (!isOpen) return null;

  return (
    <div className="signup-modal">
      <div className="signup-container-">
        <div className="signup-wrap">
          <h2>회원가입</h2>
          <div className="form-group">
            <label>이메일</label>
            <input
              type="email"
              value={email}
              className="signup-input"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>비밀번호</label>
            <input
              type="password"
              value={password}
              className="signup-input"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>비밀번호확인</label>
            <input
              type="password"
              value={confirmPassword}
              className="signup-input"
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>연락처</label>
            <input
              type="tel"
              value={phone}
              className="signup-input"
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          {error && <div className="error-message">{error}</div>}
          <button className="signupButton" 
          onClick={handleSignup} 
          disabled={!isFormValid()}>
            회원가입
          </button>
          {/* <button onClick={onClose}>닫기</button> */}
        </div>
      </div>
    </div>
  );
};
export default SignupModal;
