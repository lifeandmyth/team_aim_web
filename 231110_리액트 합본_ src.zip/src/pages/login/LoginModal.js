import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import GoogleLoginButton from './GoogleLoginButton';
import YoutubeLoginButton from './YoutubeLoginButton';
import SignupModal from './SignupModal';
import './LoginModal.css';
import HorizonLine from './HorizontalLine';
import { useEffect } from 'react';
//import youtubeicon from '../../image/youtubeicon.png'
//import googleicon from '../../image/googleicon.png'
import person from '../../image/person.png'
import lock from '../../image/lock.png'
import axios from 'axios';


const LoginModal = ({
   setIsLoggedIn,
  setModalOpen
}) => {  
   // const [loginOpen, setLoginOpen] = useState(false); 
    const [isLoginModalOpen, setIsLoginModalOpen] = useState(true);
    const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPw] =useState('');
    const [notAllow, setNotAllow]= useState(true)
    const [emailVaild, setEmailValid] = useState(false)
    const [pwVaild, setPwValid] = useState(false)

    
    const navigate = useNavigate();

 
    /* 클릭 시 회원가입 모달 열기 */
    const openSignupModal = () => {
      setIsSignupModalOpen(true); // 회원가입 모달을 열고
      setIsLoginModalOpen(false); // 로그인 모달을 닫음
  };

  /* 회원가입 모달 닫기 */
  const closeSignupModal  = () => {
      setIsSignupModalOpen(false); // 회원가입 모달을 닫음
      setIsLoginModalOpen(true); // 로그인 모달을 다시 엶
  };


    /* 이메일 유효성 */
  const handleEmail = (e) => {
    const emailValue = e.target.value;
    setEmail(emailValue);
    const regex =  /^(([^<>()\[\].,;:\s@"]+(\.[^<>()\[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/;
    if(regex.test(emailValue)){
      setEmailValid(true);
    } else {
      setEmailValid(false);
    }
  }

  /* 비밀번호 유효성 */
  const handlePassword = (e) => {
    const passwordValue = e.target.value;
    setPw(passwordValue);
    const regex = 
      /^(?=.*[a-zA-z])(?=.*[0-9])(?=.*[$`~!@$!%*#^?&\\(\\)\-_=+])(?!.*[^a-zA-z0-9$`~!@$!%*#^?&\\(\\)\-_=+]).{8,20}$/i;
    if(regex.test(passwordValue)){
      setPwValid(true);
    } else{
      setPwValid(false)
    }
  }

    /* 로그인 서버 요청 */
    const onClickConfirmButton = () => {
      // 이메일과 비밀번호를 서버로 보내는 요청
      axios
        .post("http://localhost:8080/api/user/login", {
          userEmail: email,
          userPassword: password
        })
        .then((response) => {
          // 서버로부터의 응답을 처리
          const token  = response.data; // 서버에서 'token' 이름으로 토큰을 보내줄 것으로 가정합니다.
          if (token) {
            console.log("로그인 성공,  토큰 받음: ", token);
            localStorage.setItem('token', token);
            alert("로그인에 성공했습니다.");
            setIsLoggedIn(true);
            setModalOpen(false);
            navigate(`/`, { state: { loginSuccess: true } });
          } else {
            console.log("로그인 실패", response.data);
            alert("등록되지 않은 회원입니다.");
          }
        })
        .catch((error) => {
          // 오류가 발생한 경우 처리
          console.error("로그인 요청 오류: ", error);
          alert("로그인 요청 중 오류가 발생했습니다.");
        });
    };
  

  useEffect(() => {
    if(emailVaild && pwVaild) {
      setNotAllow(false);
      return;
    }
    setNotAllow(true);

  },[emailVaild, pwVaild]);

  useEffect(() => {
    if (isLoginModalOpen || isSignupModalOpen ) {
      // 모달이 열릴 때 body 스크롤을 숨깁니다.
      document.body.style.overflow = 'hidden';
    } else {
      // 모달이 닫힐 때 body 스크롤을 복원합니다.
      document.body.style.overflow = 'visible';
    }
  
    // cleanup 함수에서는 항상 원래 스크롤을 복원합니다.
    return () => {
      document.body.style.overflow = 'visible';
    };
  }, [isLoginModalOpen, isSignupModalOpen]);





return (
  <div className='presentation'>
      <div className='wrapper-modal'>
          <div className='modal'>
          <div className='clossWrap'>
            <span
                onClick={() => setModalOpen(false)}
                className='modal-close'
            >
                X
            </span>
          </div>
            <div className='modal_content'>
              <div className='modal_details'>
                <div>
                  <h3 className='yloginTitle'>크리에이터</h3>
                </div>
                <YoutubeLoginButton />
                <div>
                  <div>
                  <h3 className='yloginTitle'>광고주</h3>
                  </div>
                <GoogleLoginButton />
                </div>
              </div>
              <div>
                <HorizonLine text="또는" />
              </div>

      {/* 로그인폼 */}
      <div className='loginWrap'>
        <div className='loginbox'>
          <div className='emailimage'>
            <img src={person} alt="person" />
          </div>
        <div className='emailinputWrap'>
        <input
            type='text'
            className='emailinput' 
            placeholder='이메일을 입력해주세요.'
            value={email} 
            onChange={handleEmail}/>
        </div>
      </div>
        <div className='loginbox'>
          <div className='pwimage'>
            <img src={lock} alt="lock" />
          </div>
          <div className='pwinputWrap'>
            <input
              type='password' 
              className='pwinput' 
              placeholder='비밀번호를 입력해주세요.'
              value={password}
              onChange={handlePassword} />
          </div>
        </div>
      </div>

      <div>
      <button onClick={onClickConfirmButton} disabled={notAllow} className='loginButton'>
        로그인
      </button>
     </div>
    
     <div className='signtext'>
      <h3>계정이 없으신가요?</h3>
      <button onClick={openSignupModal}>회원가입</button>
     </div>

     <div className='pwtext'>
      <h3>비밀번호를 잊어버리셨나요?</h3>
      <button>비밀번호 찾기</button>
     </div>
       <SignupModal isOpen={isSignupModalOpen}  onClose={closeSignupModal} />
     </div>      
   </div >
  </div>
</div>
)
}

  
export default LoginModal