import { useEffect, useState } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { callSearchKeywordsAPI, callSearchDetailAPI, callsearchModalAPI, callKeywordHistoryAPI } from '../../apis/SearchAPICall';
import { useLocation, useNavigate } from 'react-router-dom';
import searchCSS from '../search/Search.module.css';
import MatchingForm from "../matching/MatchingForm";
import BannerSlider from "../../component/BannerSlider";
import ranking5 from "../../image/ranking5.png";
import ranking4 from "../../image/ranking4.png";
import ranking3 from "../../image/ranking3.png";
import ranking2 from "../../image/ranking2.png";
import ranking1 from "../../image/ranking1.png";


function Search() {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const keywordsFromURL = queryParams.get('keywords');
    const [keywords, setKeywords] = useState(keywordsFromURL || "");
    const dispatch = useDispatch();
    const navigate = useNavigate();
    
    const search = useSelector(state => state.searchReducer);
    const searchList = search.data;
    const detail = useSelector(state => state.detailReducer);


    // const modal = useSelector(state => state.detailReducer);
    // const modalList = modal.data;

    /* 검색 기록 누적 시 사용 */
    const currentTime = new Date().toISOString();
    const requestData = {
        keywords: keywords,         // 검색할 키워드
        searchDate: currentTime     // 현재 시간을 검색 시간으로 사용
    };

    /* 페이징 처리 적용 */
    const pageInfo = search.pageInfo;
    const [currentPage, setCurrentPage] = useState(1);
    const pageNumber = [];
    if (pageInfo) {
        for (let i = 1; i <= pageInfo.pageEnd; i++) {
            pageNumber.push(i);
        }
    }

    /*구독자 표시 */
    function formatCount(count) {

        let value;
    
        if (count >= 10000) {
            value = (count / 10000).toFixed(2);
        } else if (count >= 1000) {
            value = (count / 1000).toFixed(2);
        } else {
            return count;
        }
        // 소수점 뒤에 불필요한 0을 제거
        value = parseFloat(value).toString();
    
        if (count >= 10000) {
            return value + '만';
        } else {
            return value + '천';
        }
    }

    /*모달창 해보기 */
    const [isModalOpen, setModalOpen] = useState(false);
    //const [modalData, setModalData] = useState();
    const [selectedMonth, setSelectedMonth] = useState(null);
    //const [selectedChannel, setselectedChannel] = useState(null);

    const handleOpenModal = (month,channel) => {
        setModalOpen(true);
        setSelectedMonth(month);
        dispatch(callsearchModalAPI({
            channel: channel,
            keywords: keywords,
            month: month
        },));
        console.log("매개변수 확인하기 : ", keywords, channel, month)
    };

    const [modalOpen, setIsModalOpen] = useState(false);
    
        // 모달 열기
        const openModal = () => {
            setIsModalOpen(true);
        }

    const handleCloseModal = () => {
        setModalOpen(false);
        dispatch(callSearchKeywordsAPI({
            keywords: keywords,
            currentPage: currentPage
        }));
    };

    // useEffect(() => {
    //     setKeywords(keywordsFromURL || "");
    // }, [keywordsFromURL]);
    
    useEffect(() => {
        setSortedList(searchList);
    }, [searchList]);

    /* 검색 결과 리스트 반환 */
    useEffect(() => {
        dispatch(callSearchKeywordsAPI({
            keywords: keywords,
            currentPage: currentPage
        }));
    }, [currentPage]);

    /* 리스트별 Accordion 적용 */
    const [isOpenList, setIsOpenList] = useState({});
    const accordionClick = (channel) => {
        setIsOpenList((prevOpenList) => ({
            ...prevOpenList,
            [channel]: !prevOpenList[channel],
        }));

        for (const key in isOpenList) {
            if (key !== channel) {
              setIsOpenList((prevOpenList) => ({
                ...prevOpenList,
                [key]: false,
              }));
            }
          }

        if (!isOpenList[channel]) {
            dispatch(callSearchDetailAPI({
                keywords: keywords,
                channel: channel
            },[]));
        }

        console.log("매개변수 확인 : ", keywords, channel)
    };

    const [sortedList, setSortedList] = useState([]);

    /* 정렬 함수 추가 */
    const sortBySubscriberCount = () => {
        const sortedList = [...searchList].sort((a, b) => b.subscriber_count - a.subscriber_count);
        setSortedList(sortedList);
    };

    const sortByKeywordOccurrenceCount = () => {
        const sortedList = [...searchList].sort((a, b) => b.keyword_occurrence_count - a.keyword_occurrence_count);
        setSortedList(sortedList);
    };

    const sortByViews = () => {
        const sortedList = [...searchList].sort((a, b) => b.last_12_month_video_views - a.last_12_month_video_views);
        setSortedList(sortedList);
    };

    /* 검색 키업 핸들러 */
    // const onEnterKeyHandler = (e) => {
    //     if (e.key === 'Enter') {
    //         console.log('Enter key', keywords);
            
    //         navigate(`/search?keywords=${keywords}`, { replace: true });
    //         dispatch(callSearchKeywordsAPI({
    //             currentPage: currentPage,
    //             keywords: keywords
    //         }));

    //         dispatch(callKeywordHistoryAPI(requestData));

    //         window.location.reload();
    //     }
    // }

    /* 검색 체인지 핸들러 */
    // const onSearchChangeHandler = (e) => {
    //     setKeywords(e.target.value);
    
    // }

    /* 가장 높은 막대 찾기 */
    const maxKeywordCount = Math.max(...detail.map(d => d.keyword_count));

    return (
        <>

            {/* <BannerSlider/> */}
            <div className={searchCSS.Wrap}>

            {/* <div className={searchCSS.container}>
                <div className={searchCSS.image}>
                    <span className={MainCss.text}>Hire the world's top
                        <br/>&nbsp;&nbsp;&nbsp;&nbsp;creative talent
                    </span>
                    <span className={searchCSS.text}></span>
                    <input
                        className={ searchCSS.input }
                        type='text'
                        placeholder='검색어를 입력하세요'
                        value={ keywords }
                        onKeyUp={ onEnterKeyHandler }
                        onChange={ onSearchChangeHandler }
                    />
                </div>
            </div> */}

            
            <style jsx>{`.wide{height:400px;}`}</style>
            <b className={searchCSS.searchKey}>검색한 키워드는 "<span className={searchCSS.searchKeySpan}>{keywords}</span>" 입니다</b>
            <div className={searchCSS.filterContainer}>
                <div className={searchCSS.filter}>
                    <button className={searchCSS.filterButton} onClick={ sortBySubscriberCount }>구독자</button>
                    <button className={searchCSS.filterButton} onClick={ sortByKeywordOccurrenceCount }>키워드 통계</button>
                    <button className={searchCSS.filterButton} onClick={ sortByViews }>조회수</button>
                </div>
                <a className={searchCSS.period}>(분석기간 : 최근12개월)</a>
            </div>
            <div style={{ listStyleType: "none", display: "flex", justifyContent: "center", textAlign: "center" }}>
                <ul className={searchCSS.searchlist}>
                    {Array.isArray(sortedList) && sortedList.map((m) => (
                        <li key={m.channel} className={`${searchCSS.searchtable} ${isOpenList[m.channel] ? 'wide': null}`}>
                        
                        <div className={searchCSS.leftSection}>
                            <div className={searchCSS.leftContent}>
                            <div className={searchCSS.effectScore}>
                                 {m.keyword_effect_score >= 800 ? (
                                        <img src={ranking1} alt="Very High Score" style={{ width: '35px', height: '35px' }} />
                                    ) : m.keyword_effect_score >= 600 ? (
                                        <img src={ranking2} alt="High Score" style={{ width: '35px', height: '35px' }} />
                                    ) : m.keyword_effect_score >= 400 ? (
                                        <img src={ranking3} alt="Medium Score" style={{ width: '35px', height: '35px' }} />
                                    ) : m.keyword_effect_score >= 200 ? (
                                        <img src={ranking4} alt="Low Score" style={{ width: '35px', height: '35px' }} />
                                    ) : (
                                        <img src={ranking5} alt="Very Low Score" style={{ width: '35px', height: '35px' }} />
                                    )
                                }
                                    </div>
                               <div className={searchCSS.imageBox}> <img src={m.channel_image} alt="Channel Image" width="65" style={{borderRadius: '50%'}}/> </div>
                                <div className={searchCSS.channelDetails}>
                                    <div className={searchCSS.channelName}>{m.channel}</div>
                                    {/* <div className={searchCSS.subscriberCount}>구독자 : {formatCount(m.subscriber_count)}명</div>

                                    <div className={searchCSS.subscriberCount}>업로드 영상 : {m.last_12_months_video_count}개</div> */}
                                </div>
                            </div>
                            <div className={searchCSS.rightSection}>
                                <ul class={searchCSS.leftText}>
                                    <li className={searchCSS.subscriberCount}>구독자 : {formatCount(m.subscriber_count)}명</li>
                                    <li className={searchCSS.subscriberCount}>업로드 영상 : {m.last_12_months_video_count}개</li>
                                                        
                                </ul>
                                <ul class={searchCSS.rightText}>
                                    {/* <li className={searchCSS.effectScore}>
                                        광고효과등급
                                        {m.keyword_effect_score > 600 ? (
                                            <img src="https://cdn-icons-png.flaticon.com/128/2583/2583344.png" alt="High Score" style={{ width: '30px', height: '30px' }} />
                                            ) : m.keyword_effect_score > 400 ? (
                                                <img src="https://cdn-icons-png.flaticon.com/128/2583/2583319.png" alt="Medium Score" style={{ width: '30px', height: '30px' }} />
                                                ) : (
                                                    <img src="https://cdn-icons-png.flaticon.com/128/2583/2583434.png" alt="Low Score" style={{ width: '30px', height: '30px' }} />
                                                    )}
                                    </li> */}

                                        
                                        <li className={searchCSS.keywordCount}>연간 키워드 수 {m.keyword_occurrence_count}</li>
                                        <li className={searchCSS.video_views}>연간 조회수{m.last_12_month_video_views.toLocaleString()}회</li>

                                </ul>
                                <div className={searchCSS.matchButton}>
                                    <button className={searchCSS.matchinghBtn} onClick={openModal}>매칭<br/>하기</button>
                                </div>
                                {modalOpen && <MatchingForm setModalOpen={setIsModalOpen} />}
                            </div>
                            <div className={searchCSS.detailButton}>
                                <button onClick={() => accordionClick(m.channel)}className={searchCSS.arrowBtn}>      
                                    <img 
                                        src={isOpenList[m.channel] 
                                            ? "https://cdn-icons-png.flaticon.com/128/9121/9121656.png"   // 아코디언이 열려 있을 때의 이미지
                                            : "https://cdn-icons-png.flaticon.com/128/2926/2926233.png"}  // 아코디언이 닫혀 있을 때의 이미지
                                        alt="Arrow" 
                                        width="20" 
                                        height="15"
                                        style={{opacity: 0.5}}
                                    />
                                </button>
                            </div>
                        </div>
                        {isOpenList[m.channel] && (
                            <div className={searchCSS.accoBtn}>
                                {Array.isArray(detail) && (
                                    <div className={`${searchCSS.accoBtn} ${isOpenList[m.channel]}`}>
                                        {detail.map((d) => (
                                            <div key={d.upload_month} className={searchCSS.barContainer}>
                                                <div className={searchCSS.detail} style={{ transform: 'scaleY(-1)' }}>
                                                    <div className={searchCSS.monthCount}>{d.keyword_count}</div>
                                                    <button 
                                                        className={searchCSS.monthBtn}
                                                        onClick={() => handleOpenModal(d.upload_month,d.channel)}
                                                    >
                                                        {d.upload_month}
                                                    </button>
                                                </div>
                                                <div className={searchCSS.bar} style={{ height: `${d.keyword_count * 7}px`,
                                                    backgroundColor: d.keyword_count === maxKeywordCount ? 'hotpink' : '#ba9fd4' }}>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}
                        </li>
                    ))}

{isModalOpen&& (
                       <div className={searchCSS.modal}>
                       <div className={searchCSS.modalContent}>
                         <button onClick={handleCloseModal} className={searchCSS.closeBtn}>X</button>
                         {Array.isArray(search) && (
                            <div>
                                <h2>{selectedMonth}</h2>
                                {search.reduce((acc, q, index, array) => {
                                const isNewTitle = index === 0 || q.title !== array[index - 1].title;
                                if (isNewTitle) {
                                    if (acc.currentContainer.length > 0) {
                                    acc.components.push(
                                        <div key={acc.lastTitle}>
                                        <div className={searchCSS.titleWithIcon}>
                                            <img src="https://cdn-icons-png.flaticon.com/128/3128/3128307.png" alt="Video Icon" className={searchCSS.videoIcon} />
                                            <h5 className={searchCSS.videoTitle}>{acc.lastTitle}</h5>
                                        </div>
                                        <div className={searchCSS.timePointContainer}>{acc.currentContainer}</div>
                                        </div>
                                    );
                                    }
                                    acc.currentContainer = [
                                    <a href={`${q.vid_url}&t=${q.timeline}s`} target="_blank" rel="noopener noreferrer" className={searchCSS.timePointLink} key={q.timeline}>
                                        <div className={searchCSS.timePointBox}>{q.timeline}s</div>
                                    </a>
                                    ];
                                    acc.lastTitle = q.title;
                                } else {
                                    acc.currentContainer.push(
                                    <a href={`${q.vid_url}&t=${q.timeline}s`} target="_blank" rel="noopener noreferrer" className={searchCSS.timePointLink} key={q.timeline}>
                                        <div className={searchCSS.timePointBox}>{q.timeline}s</div>
                                    </a>
                                    );
                                }
                                if (index === array.length - 1) {
                                    acc.components.push(
                                    <div key={acc.lastTitle}>
                                        <div className={searchCSS.titleWithIcon}>
                                        <img src="https://cdn-icons-png.flaticon.com/128/3128/3128307.png" alt="Video Icon" className={searchCSS.videoIcon} />
                                        <h5 className={searchCSS.videoTitle}>{acc.lastTitle}</h5>
                                        </div>
                                        <div className={searchCSS.timePointContainer}>{acc.currentContainer}</div>
                                    </div>
                                    );
                                }
                                return acc;
                                }, { lastTitle: '', currentContainer: [], components: [] }).components}
                            </div>
                            )}
                       </div>
                     </div>
                    )}
                </ul>
            </div><br/>

            {/* 페이징 버튼 */}
            <div style={{ listStyleType: "none", display: "flex", justifyContent: "center" }}>
                { Array.isArray(searchList) &&
                    <button 
                        className={ searchCSS.pagingBtn }
                        onClick={() => setCurrentPage(currentPage - 1)} 
                        disabled={currentPage === 1}
                    >
                        &lt;
                    </button>
                }&nbsp;&nbsp;
                {pageNumber.map((num) => (
                    <div key={num} onClick={() => setCurrentPage(num)}>
                        <button
                            className={ searchCSS.pagingNumBtn }
                            style={ currentPage === num ? {backgroundColor : '#ba9fd4' } : null}
                        >
                            {num}
                        </button>&nbsp;&nbsp;
                    </div>
                ))}
                { Array.isArray(searchList) &&
                    <button 
                        className={ searchCSS.pagingBtn }
                        onClick={() => setCurrentPage(currentPage + 1)} 
                        disabled={currentPage === pageInfo.pageEnd  || pageInfo.total === 0}
                    >
                        &gt;
                    </button>
                }
            </div>
            </div>
        </>        
    )
}

export default Search;