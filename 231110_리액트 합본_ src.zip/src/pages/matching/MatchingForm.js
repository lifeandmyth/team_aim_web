import React, { useEffect, useState } from "react";
import "./MatchingForm.css";
//import { useNavigate } from 'react-router-dom';
import MatchingPre from "./MatchingPre";

const MatchingForm = ({ setModalOpen, formData: initialFormData }) => {
  //const MatchingForm = ({setModalOpen, forminitialFormData }) => {

  // const navigate = useNavigate();
  const [MpreOpen, setMpreOpen] = useState(false);
  const [notAllow, setNotAllow] = useState(true);
  const [matchingTitle, setMatchingTitle] = useState("");
  const [provider, setProvider] = useState("");
  const [userSendName, setUserSendName] = useState("");
  const [matchingDetails, setMatchingDetail] = useState("");
  const [matchingCostsMin, setMatchingCostsMin] = useState("");
  const [matchingCostsMax, setMatchingCostsMax] = useState("");
  // const [roundedMinAdCost, setRoundedMinAdCost] = useState("");
  // const [roundedMaxAdCost, setRoundedMaxAdCost] = useState("");
  const [calculatedMinAdCost, setCalculatedMinAdCost] = useState("");
  const [calculatedMaxAdCost, setCalculatedMaxAdCost] = useState("");
  const [matchingGoal, setMatchingGoal] = useState("선택");
  const [adMethodsDetails, setAdMethodDetails] = useState("선택");

  const [minAdCost, setMinAdCost] = useState("");
  const [maxAdCost, setMaxAdCost] = useState("");

  const [formData, setFormData] = useState(
    initialFormData || {
      matchingTitle: "",
      provider: "",
      userSendName: "",
      matchingDetails: "",
      matchingCostsMin: "",
      matchingCostsMax: "",
      matchingGoal,
      adMethodsDetails
    }
  );

  /* 클릭 시 매칭미리보기페이지로 이동 */
  const onClickMpreHandler = () => {
    setMpreOpen(true);
    //  setModalOpen(false);
  };

  // 타이틀
  const handleTitleChange = (event) => {
    setMatchingTitle(event.target.value);
    setFormData({ ...formData, matchingTitle: event.target.value });
  };

  // 회사명
  const handleCompanyChange = (event) => {
    setProvider(event.target.value);
    setFormData({ ...formData, provider: event.target.value });
  };

  // 담당자 성함
  const handleEmailChange = (event) => {
    setUserSendName(event.target.value);
    setFormData({ ...formData, userSendName: event.target.value });
  };

  //광고 소개 ()
  const handleaAdIntroChange = (event) => {
    const text = event.target.value;
    const textWithNewlines = text.replace(/\n/g, "<br>");
    // setAdIntro(event.target.value);
    setMatchingDetail(text);
    setFormData({ ...formData, matchingDetails: textWithNewlines });
  };

  //광고제작의뢰목적(셀렉트)
  const handleSlect1Change = (event) => {
    const selectedOption = event.target.options[event.target.selectedIndex];
    const selectedText = selectedOption.textContent;
    setFormData({ ...formData, matchingGoal: selectedText });
  };

  //영상제작방식(셀렉트)
  const handleSlect2Change = (event) => {
    const selectedOption = event.target.options[event.target.selectedIndex];
    const selectedText = selectedOption.textContent;
    setFormData({ ...formData, adMethodsDetails: selectedText });
  };

  /* 광고 예상 수익 = 조회수(DB) * 0.326(View Rate) * 0.0065(CTR) * 73633.33(상품구매가 평균) * 0.0206
적정 광고 단가(=크리에이터에게 적당히 얼마나 줄거냐)  = 광고 예상 수익 / 3 */

  //최소금액
  const handleMinCostChange = (event) => {
    const inputValue = parseFloat(event.target.value);
    const calculatedMinAdCost =
      inputValue * (0.326 * 0.0065 * 73633.33 * 0.0206) * 3;
    const roundedMinAdCost = Math.floor(calculatedMinAdCost);
    setFormData({ ...formData, matchingCostsMin: inputValue });
    setMatchingCostsMin(inputValue);
    setMinAdCost(calculatedMinAdCost);
    setCalculatedMinAdCost(roundedMinAdCost);
  };

  //최대금액
  const handleMaxCostChange = (event) => {
    const inputValue = parseFloat(event.target.value);
    const calculatedMaxAdCost =
      inputValue * (0.326 * 0.0065 * 73633.33 * 0.0206) * 3;
    const roundedMaxAdCost = Math.floor(calculatedMaxAdCost);
    setFormData({ ...formData, matchingCostsMax: inputValue });
    setMatchingCostsMax(inputValue);
    setMaxAdCost(calculatedMaxAdCost);
    setCalculatedMaxAdCost(roundedMaxAdCost);
  };

  // 하나라도 비어있으면 notAllow를 true로 설정합니다.
  useEffect(() => {
    if (
      matchingTitle === "" ||
      provider === "" ||
      userSendName === "" ||
      matchingDetails === "" ||
      matchingCostsMin === "" ||
      matchingCostsMax === "" ||
      adMethodsDetails === ""
    ) {
      setNotAllow(true);
    } else {
      setNotAllow(false);
    }
  }, [
    matchingTitle,
    provider,
    userSendName,
    matchingDetails,
    matchingCostsMin,
    matchingCostsMax,
    adMethodsDetails
  ]);

  // 모달창이 켜져있으면 뒤에 스크롤 안움직이게 하기

  useEffect(() => {
    if (setModalOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "visible";
    }

    return () => {
      document.body.style.overflow = "visible";
    };
  }, [setModalOpen]);

  return (
    <div>
      {MpreOpen ? (
        <MatchingPre formData={formData} setModalOpen={setModalOpen} />
      ) : (
        <div className="MatchingWrap">
          <div className="MContentWrap">
            <span onClick={() => setModalOpen(false)} className="Mmodal-close">
              X
            </span>
            <div className="McontentTitle">
              <h2>광고제안</h2>
            </div>

            <div className="Mcontent">
              <div className="MinputTitle">제안서 제목</div>
              <div className="MinputWrap">
                <input
                  type="text"
                  className="Minput"
                  value={matchingTitle}
                  placeholder="제목을 작성해주세요."
                  onChange={handleTitleChange} // Set the onChange function
                />
              </div>

              <div className="MinputTitle">회사명</div>
              <div className="MinputWrap">
                <input
                  type="text"
                  className="Minput"
                  value={provider}
                  onChange={handleCompanyChange} // Set the onChange function
                  placeholder="회사명을 작성해주세요."
                />
              </div>

              <div className="MinputTitle">담당자 성함</div>
              <div className="MinputWrap">
                <input
                  type="text"
                  className="Minput"
                  value={userSendName}
                  placeholder="담당자 성함을 작성해주세요."
                  onChange={handleEmailChange} // Set the onChange function
                />
              </div>
              <div className="MinputTitle">광고 소개</div>
              <div className="MinputWrap">
                <textarea
                  className="Mtextarea"
                  value={matchingDetails}
                  placeholder="광고소개&#13;&#10;
            ** 상품 설명, 광고 진행 목적, 광고 예산, 일정 등 작성해주세요.&#13;&#10;
            ** 기타사항 작성해주세요."
                  onChange={handleaAdIntroChange}
                />
              </div>

              <div className="MinputTitle">영상제작의뢰목적</div>
              <div
                className="MinputWrap"
                value={matchingGoal}
                onChange={handleSlect1Change}
              >
                <select className="Mselect">
                  <option value="1">선택</option>
                  <option value="2">제품소개</option>
                  <option value="3">브랜드 인지도 증대</option>
                  <option value="4">이벤트 참여 유도</option>
                  <option value="5">바이럴 효과 유도</option>
                  <option value="6">간접 광고</option>
                </select>
              </div>

              <div className="MinputTitle">광고 예산</div>
              <div>
                <div style={{ width: "170px" }} className="MinInputWrap">
                  <input
                    type="text"
                    className="Minput"
                    value={matchingCostsMin}
                    onChange={handleMinCostChange}
                  />
                </div>
                <span className="Tilde">~</span>
                <div style={{ width: "170px" }} className="MinInputWrap">
                  <input
                    type="text"
                    className="Minput"
                    value={matchingCostsMax}
                    onChange={handleMaxCostChange}
                  />
                </div>
              </div>

              {/* 임시 부분 */}
              <div>
                <div className="MinputTitle">광고 예상 단가</div>
                <div>
                  <div className="MinInputWrap1" style={{ width: "170px" }}>
                    <span className="Minput1">{calculatedMinAdCost}</span>
                  </div>
                  <span className="Tilde">~</span>
                  <div className="MinInputWrap1" style={{ width: "170px" }}>
                    <span className="Minput1">{calculatedMaxAdCost}</span>
                  </div>
                </div>
              </div>

              <div className="MinputTitle">영상제작방식</div>
              <div
                className="MinputWrap"
                value={adMethodsDetails}
                onChange={handleSlect2Change}
              >
                <select className="Mselect">
                  <option value="1">선택</option>
                  <option value="2">
                    기획 및 제작까지 모두 유튜버에게 맡김
                  </option>
                  <option value="3">
                    생각한 컨셉을 전달하고 콘텐츠 제작은 유튜버에게 맡김
                  </option>
                  <option value="4">기타</option>
                </select>
              </div>

              <div className="buttonWrap">
                <button
                  className="NextButton"
                  disabled={notAllow}
                  onClick={onClickMpreHandler}
                >
                  다음
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatchingForm;
