import React, { useState } from "react"
import LoginModal from './LoginModal';
import SignupModal from './SignupModal';
import MatchingForm from "./MatchingForm";

const ParentComponent = () => {
    const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
    const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
    const [isMatchingFormOpen, setIsMatchingFormOpen] = useState(false);

    const openLoginModal = () => {
        setIsLoginModalOpen(true);
    };

    const closeLoginModal = () => {
        setIsLoginModalOpen(false);
    };

    const openSignupModal = () => {
        setIsSignupModalOpen(true);
    };

    const closeSignupModal = () => {
        setIsSignupModalOpen(false);
    };

    const openMatchingForm = () => {
        setIsMatchingFormOpen(true);
    };

    const closeMatchingForm = () => {
        setIsMatchingFormOpen(false);
    };

    return(
        <div>
            <button onClick={openLoginModal}>로그인</button>
            <button onClick={openSignupModal}>회원가입</button>
            <button onClick={openMatchingForm}>매칭하기</button>
            <LoginModal isOpen={isLoginModalOpen} onClose={closeLoginModal} />
            <SignupModal isOpen={isSignupModalOpen} onClose={closeSignupModal} />
            <MatchingForm isOpen={isMatchingFormOpen} onClose={closeMatchingForm} />
        </div>
    )
}
export default ParentComponent;