import React, { useState } from "react";
import MatchingForm from "./MatchingForm";
import { useNavigate } from "react-router-dom";

const MatchingPage = () => {

   // const [isMatchingFormOpen, setIsMatchingFormOpen] = useState(true);
    const navigate = useNavigate();
    const [modalOpen, setModalOpen] = useState(false);

    // const openMatchingForm = () => {
    //     setIsMatchingFormOpen(true);
    // }

    // const closeMatchingForm = () => {
    //     setIsMatchingFormOpen(false);
    // }


    // 모달 열기
    const openModal = () => {
        setModalOpen(true);
    }


    // 매칭 데이터 예시 (이미지 URL, 채널명, 구독자수, 랭킹 정보 등)
    const channels = [
        {
            id: 1,
            imageUrl: 'https://example.com/channel1.jpg',
            channelName: '채널 1',
            subscribers: 1000000,
            ranking: 1,
        },
        {
            id: 2,
            imageUrl: 'https://example.com/channel1.jpg',
            channelName: '채널 2',
            subscribers: 30000,
            ranking: 2,
        }
        // 다른 채널 데이터들 추가 가능
    ];
    
    return (
      <>
      <div className="matching-page">
        {channels.map(channel => (
            <div key={channel.id} className="channel-card">
                <img src={channel.imageUrl} alt={channel.channelName} className="channel-image" />
                <h2>{channel.channelName}</h2>
                <p>구독자수: {channel.subscribers}</p>
                <p>랭킹: {channel.ranking}</p>
                {/* 매칭하기 버튼 클릭 시 모달창 열리도록 이벤트 핸들러를 등록합니다. */}
                {/* <button className="matching-btn" onClick={openMatchingForm}>매칭하기</button> */}
                 <button className="matching-btn" onClick={openModal}>매칭하기</button> 
            </div>
        ))};
         {/* isMatchingFormOpen 상태가 true일 때만 MatchingForm 모달창이 열립니다.
         - 아래내용은 우선 삭제, 매칭페이지에 매칭폼이 같이 나옴  */}
    </div>
    {modalOpen && <MatchingForm setModalOpen={setModalOpen} />}
    </>
    );
};
export default MatchingPage;