import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MatchingForm from './MatchingForm';
import './MatchingPre.css';
import axios from 'axios';

const MatchingPre = ({setModalOpen, formData}) => {
  const navigate = useNavigate();
  const [MFormOpen, setMFormOpen] = useState(false);

 // textarea 엔터를 개행(<br>)으로 렌더링하기 위한 함수 
  const renderAdIntroWithNewlines = () => {
    return { __html: formData.matchingDetails.replace(/(\r\n|\n|\r)/g, '<br>') };
  };


    const onClickMFormHandler = () => {
      setMFormOpen(true);

  }

  // 매칭완료 후 메인페이지로 이동 
  const onClickMCompleteHandler = async () => {
    try {
    const response = await axios.post('http://localhost:8080/api/user/matching/upload', {
      matchingTitle: formData.matchingTitle,
      provider: formData.provider,
      userSendName: formData.userSendName,
      matchingDetails: formData.matchingDetails,
      matchingGoal: formData.matchingGoal,
      matchingCostsMin: formData.matchingCostsMin,
      matchingCostsMax: formData.matchingCostsMax,
      adMethodsDetails: formData.adMethodsDetails
    });
    console.log(response.data);
    console.log("매칭완료페이지로 이동")
    alert('매칭제안을 보냈습니다.');
    navigate("/", { replace: false })
} catch (error) {
  console.error("Error sending data to backend:", error);
}
};


  // 모달창이 켜져있으면 뒤에 스크롤 안움직이게 하기

  useEffect(() => {
    if (setModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'visible';
    }
  
    return () => {
      document.body.style.overflow = 'visible';
    };
  }, [setModalOpen]);


  return (
    <div> 
      {MFormOpen ? (
      <MatchingForm setModalOpen={setModalOpen}/>
    ) : (
    <div>
      <div className='MatchingWrap'>
      <div className='MContentWrap'>
      <span
              onClick={() => setModalOpen(false)}
              className='Mmodal-close'
          >
              X
          </span>
        <div className="McontentTitle">
          <h2>광고제안</h2>
        </div>

      <div className='viewBox1' >
      <div className='viewTitle'>제안서 제목: </div>
      <div className='viewanswer'> {formData.matchingTitle}</div>
     </div>

     <div className='viewBox'>
      <div className='viewTitle'>회사명: </div>
      <div className='viewanswer'>{formData.provider}</div>
     </div>

     <div className='viewBox'>
      <div className='viewTitle'>담당자 이메일: </div>
      <div className='viewanswer'> {formData.userSendName}</div>
    </div>

    <div className='viewBox'>
      <div className='viewTitle'>광고 소개: </div>
      <div className='viewanswer' dangerouslySetInnerHTML={renderAdIntroWithNewlines()}></div>
    </div>
    
    <div className='viewBox'>
      <div className='viewTitle'>영상제작의뢰목적: </div> 
      <div className='viewanswer'> {formData.matchingGoal}</div>
    </div>

    <div className='viewBox'>
      <div className='viewTitle'>광고예산: </div>  
      <div className='viewanswer'>{formData.matchingCostsMin} ~ {formData.matchingCostsMax}</div>
    </div>

    <div className='viewBox'>
      <div className='viewTitle'>영상제작방식: </div> 
      <div className='viewanswer'> {formData.adMethodsDetails}</div>
    </div>
      <div className='preButtonWrap'>
        <div className='backBox'>
          <button className='BackButton' onClick={onClickMFormHandler}>뒤로가기</button>
        </div>
        <div className='submitBox'>
          <button className='SubmitButton' onClick={onClickMCompleteHandler}>보내기</button>
        </div>
      </div>
    </div>
    </div>
    </div>
    )}
    </div>
  )
};

export default MatchingPre;