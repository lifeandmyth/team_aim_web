function Ranking() {



    return(
        <h1>랭킹페이지</h1>
    )
}

export default Ranking;