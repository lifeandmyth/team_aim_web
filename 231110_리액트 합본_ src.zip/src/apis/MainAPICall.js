import {
    GET_MAIN
} from '../modules/MainModule.js';

export const callMainListAPI = ({currentPage}) => {
    
    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/main`;

    if (currentPage !== undefined || currentPage !== null) {
        requestURL = `${requestURL}?offset=${currentPage}`;
    }

    console.log('[callMainListAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){

            console.log('[ProduceAPICalls] callMainListAPI RESULT : ', result);

            dispatch({ type: GET_MAIN,  payload: result.data });
        }
    };
}