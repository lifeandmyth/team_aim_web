import { GET_SEARCH, GET_SEARCHURL, POST_KEYWORD, GET_KEYWORDRANKING } from '../modules/SearchModule.js';
import { GET_SEARCHDETAIL } from '../modules/DetailModule.js';

export const callSearchKeywordsAPI = ({currentPage, keywords}) => {
    
    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/search`;

    if (keywords !== undefined || keywords !== null) {
        requestURL = `${requestURL}?offset=${currentPage}&keywords=${keywords}`;
    }

    console.log('[callSearchKeywordsAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){

            console.log('[ProduceAPICalls] callSearchKeywordsAPI RESULT : ', result);

            dispatch({ type: GET_SEARCH,  payload: result.data });
        }
    };
}

export const callSearchDetailAPI = ({keywords, channel}) => {
    
    // console.log("API에서 값 확인하기 : " , keywords, channel)

    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/searchdetail`;

    if (keywords !== undefined || keywords !== null) {
        requestURL = `${requestURL}?channel=${channel}&keywords=${keywords}`;
    }

    console.log('[callSearchDetailAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){

            console.log('[ProduceAPICalls] callSearchDetailAPI RESULT : ', result);
            // console.log("제발좀와라", result.data)

            dispatch({ type: GET_SEARCHDETAIL,  payload: result.data });

            // console.log("버튼 클릭 시 확인!!!!!!!!!!!!!!!!")
        }
    };
}

export const callsearchModalAPI = ({ channel, keywords, month }) => {
    
    console.log("API에서 값 확인하기 : " , keywords, channel, month)

    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/searchmodal`;

    if (keywords !== undefined || keywords !== null) {
        requestURL = `${requestURL}?keywords=${keywords}&channel=${channel}&month=${month}`;
    }

    console.log('[callsearchModalAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){
 
            console.log('[callsearchModalAPI] callsearchModalAPI RESULT : ', result);

            dispatch({ type: GET_SEARCHURL,  payload: result.data });
        }
    };
}

// 검색한 키워드 기록을 db에 저장하기 위한 api

export const callKeywordHistoryAPI = (requestData) => {
    console.log('[MypageAPICalls] callExtraworkRegistAPI Call');

    const requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/keywordHistory`;

    return async (dispatch, getState) => {

        console.log("확인해보기 : " + requestData);
        const result = await fetch(requestURL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"
            },
            body: JSON.stringify(requestData)
        })
        .then(response => response.json());

        console.log('[callKeywordHistoryAPI] callKeywordHistoryAPI RESULT : ', result);

        dispatch({ type: POST_KEYWORD,  payload: result });
        
    };    
}


export const callkeywordrankingAPI = () => {
    
    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/historyranking`;

    // if (keywords !== undefined || keywords !== null) {
    //     requestURL = `${requestURL}?keywords=${keywords}&channel=${channel}&month=${month}`;
    // }

    console.log('[callsearchModalAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){
 
            console.log('[callkeywordrankingAPI] callkeywordrankingAPI RESULT : ', result);

            dispatch({ type: GET_KEYWORDRANKING,  payload: result.data });
        }
    };
}