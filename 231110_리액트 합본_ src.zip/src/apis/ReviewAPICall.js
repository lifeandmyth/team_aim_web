import {
    GET_REVIEW
} from '../modules/ReviewModule';

export const callReviewListAPI = ({currentPage}) => {
    
    let requestURL = `http://${process.env.REACT_APP_RESTAPI_IP || 'localhost'}:8080/review`;

    if (currentPage !== undefined || currentPage !== null) {
        requestURL = `${requestURL}?offset=${currentPage}`;
    }

    console.log('[callReviewListAPI] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"                
            }
        })
        .then(response => response.json());

        if(result.status === 200){

            console.log('[ProduceAPICalls] callReviewListAPI RESULT : ', result);

            dispatch({ type: GET_REVIEW,  payload: result.data });
        }
    };
}