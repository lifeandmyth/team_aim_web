// import FooterCSS from './Footer.module.css';
import "./Footer.css";

function Footer() {
  // const navigate = useNavigate();

  return (
    <div className="Footer-Conteiner">
      {/* <h3>Copyright 2023. AIm All rights reserved. </h3> */}
      <div className="Footer-Logo">LOGO</div>
      <div className="Footer-Text">
        Copyright ⓒ 2023 AIm All Rights Reserved.
      </div>
      <div className="Footer-Icons">
        <div className="Footer-Icon1" />
        <div className="Footer-Icon2" />
        <div className="Footer-Icon3" />
      </div>
    </div>
  );
}

export default Footer;
