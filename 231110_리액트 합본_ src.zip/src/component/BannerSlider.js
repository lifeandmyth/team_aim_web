import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import banner1 from '../image/banner1.png';
import banner2 from '../image/banner2.png';
import banner3 from '../image/banner3.png';
import BannerCss from '../component/Banner.css'

const BannerSlider = () => {
  return (
    <Carousel className={BannerCss.carousel} infiniteLoop useKeyboardArrows autoPlay showThumbs={false} showArrows={false}>
          <div>
            <img src={banner1} style={{ width: '1200px', height: '350px', borderRadius: '20px' }}/>
          </div>
          <div>
            <img src={banner2} style={{ width: '1200px', height: '350px'}}/>
          </div>
          <div>
            <img src={banner3} style={{ width: '1200px', height: '350px'}}/>
          </div>
    </Carousel>
  );
};

export default BannerSlider;
