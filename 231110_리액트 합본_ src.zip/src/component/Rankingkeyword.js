import { useEffect } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { callkeywordrankingAPI } from '../apis/SearchAPICall';
import RKCss from './RK.module.css';


function Rankingkeyword() {

    const dispatch = useDispatch();

    const ranking = useSelector(state => state.searchReducer);

    useEffect(() => {
        dispatch(callkeywordrankingAPI({
        }));
    }, []);

    return (
        <>
            <div className={RKCss.container}>
                <div className={RKCss.searchtitle}>검색어 순위</div>
                <div className={RKCss.RKList} style={{ height: '150px' }}>
                    {Array.isArray(ranking) && (() => {
                    const maxKeywordPercentage = Math.max(...ranking.map(p => p.keyword_percentage));
                    return ranking.map((p, index) => (
                        <div key={index} className={RKCss.barContainer}>
                            <div
                                className={RKCss.bar}
                                style={{
                                height: `${p.keyword_percentage*4}px`,
                                backgroundColor: p.keyword_percentage === maxKeywordPercentage ? 'hotpink' : '#ba9fd4;',
                                
                                }}
                            ></div>
                            <div class={RKCss.bottomLine}>
                                <div className={RKCss.keywordLabel}>{p.keywords}</div>
                                <div className={RKCss.percentageLabel}>{p.keyword_percentage}%</div>
                            </div>
                        </div>
                    ));
                    })()}
                </div>
            </div>
        </>
    );
}


export default Rankingkeyword;
