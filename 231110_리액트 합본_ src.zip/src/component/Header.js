import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import React, { useEffect, useState } from "react";
import { callSearchKeywordsAPI, callKeywordHistoryAPI } from '../apis/SearchAPICall';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import  ReactDOM  from "react-dom";
import "./Header.css";
import LoginModal from "../pages/login/LoginModal";
import MyPage from "../image/mypage.png";
import Logo2 from "../image/LOGO_ex13.png"

// npm install --save @fortawesome/fontawesome-free

function Header() {

  const dispatch = useDispatch();
  const navigate = useNavigate();

 // const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const currentTime = new Date().toISOString();
  const [currentPage, setCurrentPage] = useState(1);

  const [keywords, setKeywords] = useState("");

  const requestData = {
    keywords: keywords,         // 검색할 키워드
    searchDate: currentTime     // 현재 시간을 검색 시간으로 사용
  };

  /* 로고 클릭 시 메인 페이지로 이동 */
  const onClickLogoHandler = () => {
    console.log("홈 버튼 실행됨");
    navigate("/", { replace: true });
  };

  /* 클릭 시 랭킹 페이지로 이동 */
  const onClickRankingHandler = () => {
    console.log("랭킹페이지로 이동");
    navigate("/Ranking", { replace: false });
  };

    /* 클릭 시 리뷰 페이지로 이동 */
    const onClickReviewHandler = () => {
      console.log("리뷰페이지로 이동");
      navigate("/Review", { replace: false });
    };

  /* 클릭 시 마이 페이지로 이동 */
  const onClickMyPagehandler = () => {
    navigate("/mypage/main", { replace: false });
  };

  // /* 로그인 모달 오픈 */
  // const openLoginModalHandler = () => {
  //   setModalOpen(true);
  // };

  // 모달 열기
  const openModal = () => {
    setModalOpen(true);
  };


  const onEnterKeyHandler = (e) => {
    if (e.key === "Enter") {
      // console.log('Enter key', keywords);
            
      navigate(`/search?keywords=${keywords}`, { replace: true });
      dispatch(callSearchKeywordsAPI({
          currentPage: currentPage,
          keywords: keywords
      }));

      dispatch(callKeywordHistoryAPI(requestData));

      window.location.reload();
    }
  };


  /* 검색 체인지 핸들러 */
  const onSearchChangeHandler = (e) => {
    setKeywords(e.target.value);
  };

  /* 로그인 상태 확인 함수 */ 
  const checkLoginStatus = () => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  };

    // 컴포넌트 마운트 시 로그인 상태 확인
    useEffect(() => {
      checkLoginStatus();
    }, []);


  /* 로그아웃 */
  const logoutHandler = () => {
    localStorage.removeItem('token'); // 토큰을 로컬 스토리지에서 제거합니다.
    setIsLoggedIn(false); // isLoggedIn 상태를 업데이트합니다.
    navigate("/", { replace: false });
  };

  return (
    <div className="Header-Container">
      <div className="Header-Wrap">
        <div
          className="Header-Logo"
          onClick={onClickLogoHandler}
          style={{ cursor: "pointer" }}
        >
          {/* <img src={AImLogo} /> */}
          <img src={Logo2} />
        </div>
        <div className="Header-Search-Container">
          <input
            className="Header-Search-Input"
            type="text"
            placeholder="검색어를 입력하세요"
            value={keywords}
            onKeyUp={onEnterKeyHandler}
            onChange={onSearchChangeHandler}
          />
          <button className="Header-Search-Icon" onClick={onEnterKeyHandler}>
            <FontAwesomeIcon icon={faSearch} />
          </button>
        </div>
        <div className="Header-Btn-Container">
          <button
            className="Header-Btn-Ranking"
            onClick={onClickRankingHandler}
          >
            랭킹
          </button>
          <button 
          className="Header-Btn-Review"
          onClick={onClickReviewHandler}>리뷰</button>
          <button className="Header-Btn-Qna">문의</button>
          {/* <button onClick={openModal}>로그인</button> */}
          {isLoggedIn ? (
            <>
              <button className="Header-Btn-Logout" onClick={logoutHandler}>
                로그아웃
              </button>
              <button
                className="Header-Btn-Mypage"
                onClick={onClickMyPagehandler}
              >
                <img src={MyPage} className="mypageImage"/>
              </button>
            </>
          ) : (
            <button className="Header-Btn-Login" onClick={openModal}>
              로그인
            </button>
          )}
           {modalOpen && ReactDOM.createPortal(
        <LoginModal setModalOpen={setModalOpen} setIsLoggedIn={setIsLoggedIn} />,
        document.getElementById('modal-root') // 모달을 modal-root에 렌더링
      )}
          {/* {modalOpen && <LoginModal setModalOpen={setModalOpen} setIsLoggedIn={setIsLoggedIn}/>} */}
        </div>
      </div>
    </div>
  );
}

export default Header;
