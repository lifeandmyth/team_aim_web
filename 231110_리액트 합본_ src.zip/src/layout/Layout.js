// import { Outlet, useNavigate } from "react-router-dom";
import Header from "../component/Header";
//import Footer from "../component/Footer";
import { Outlet } from "react-router-dom";

function MainLayout() {
    
    // const navigate = useNavigate();

    return (
        <>
            <Header/>
            <div className="outlet" style={{ backgroundColor: "#FBFBFB"}}>
            <Outlet/>
            </div>
            {/* <Footer/> */}
        </>
    )
}

export default MainLayout;