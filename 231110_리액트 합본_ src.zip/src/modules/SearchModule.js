import { createActions, handleActions } from 'redux-actions';

/* 초기값 */
const initialState = [];

/* 액션 */
export const GET_SEARCH            = 'search/GET_SEARCH';
export const GET_SEARCHURL         = 'search/GET_SEARCHURL'
export const POST_KEYWORD          = 'search/POST_KEYWORD'
export const GET_KEYWORDRANKING    = 'search/GET_KEYWORDRANKING'


const actions = createActions({
    [GET_SEARCH]: () => {},
    [GET_SEARCHURL]: () => {},
    [POST_KEYWORD]: () => {},
    [GET_KEYWORDRANKING]: () => {}
});

/* 리듀서 */
const searchReducer = handleActions(
    {
        
        [GET_SEARCH]: (state, { payload }) => {

            // console.log("★★★★★searchmodule페이로드 확인★★★★★", payload);

            return payload;
        },
        
        [GET_SEARCHURL]: (state, { payload }) => {

            // console.log("★★★★★SEARCHURL페이로드 확인", payload);

           return payload;
        },

        [POST_KEYWORD]: (state, { payload }) => {

           return payload;
        },

        [GET_KEYWORDRANKING]: (state, { payload }) => {

            return payload;
        }
       
    },
    initialState
);

export default searchReducer;