import { combineReducers } from 'redux';
import mainReducer from './MainModule';
import searchReducer from './SearchModule';
import detailReducer from './DetailModule';
import reviewReducer from './ReviewModule';

const rootReducer = combineReducers({
    mainReducer,
    searchReducer,
    detailReducer,
    reviewReducer
});

export default rootReducer;
