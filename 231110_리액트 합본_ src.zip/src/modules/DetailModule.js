import { createActions, handleActions } from 'redux-actions';

/* 초기값 */
const initialState = [];

/* 액션 */
export const GET_SEARCHDETAIL      = 'search/GET_SEARCHDETAIL'

const actions = createActions({
    [GET_SEARCHDETAIL]: () => {}
});

/* 리듀서 */
const detailReducer = handleActions(
    {
        [GET_SEARCHDETAIL]: (state, { payload }) => {

            console.log("★★★★★detailmodule페이로드 확인★★★★★", payload);

            return payload;
        }
        
    },
    initialState
);

export default detailReducer;