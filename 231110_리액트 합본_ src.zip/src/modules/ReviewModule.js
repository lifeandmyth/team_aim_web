import { createActions, handleActions } from 'redux-actions';

/* 초기값 */
const initialState = [];

/* 액션 */
export const GET_REVIEW            = 'review/GET_REVIEW';

const actions = createActions({
    [GET_REVIEW]: () => {}
});

/* 리듀서 */
const reviewReducer = handleActions(
    {
        [GET_REVIEW]: (state, { payload }) => {
            console.log('나오나????????????????????'+payload);

            return payload;
        }
    },
    initialState
);

export default reviewReducer;