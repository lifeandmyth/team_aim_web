import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './layout/Layout';

import Main from './pages/main/Main';
import Ranking from './pages/ranking/Ranking';
import Search from './pages/search/Search';
import LoginModal from './pages/login/LoginModal';
import GoogleLoginRedirectHandler from './pages/login/GoogleLoginRedirectHandler';
import MatchingPage from './pages/matching/MatchingPage';
import MatchingForm from './pages/matching/MatchingForm';
import MatchingPre from './pages/matching/MatchingPre';
import Review from './pages/review/Review'
import MatchingDetail from './pages/mypage/MatchingDetail'
import Mypage from './pages/mypage/Mypage'

import './App.css'

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={ <Layout/> }>
          <Route path="/" element={ <Main/> } />
          <Route path="Ranking" element={ <Ranking/> }/>
          <Route path="Search" element={ <Search/> }/>

          <Route path="LoginModal" element={ <LoginModal/> }/>
          <Route path="MatchingForm" element={<MatchingForm />} />
          <Route path="Matching" element={<MatchingPage />} />
          <Route path="MatchingPre" element={<MatchingPre />} />

          <Route path="/googlelogin" element={<GoogleLoginRedirectHandler />} />
          <Route path="/mypage/main" element={ <Mypage />} />
          <Route path="/matching/detail/:matchingIdx" element= {<MatchingDetail />} />
          <Route path="Review" element={ <Review/> }/>

        </Route>
      </Routes>
    </BrowserRouter>
    
  );
}

export default App;
